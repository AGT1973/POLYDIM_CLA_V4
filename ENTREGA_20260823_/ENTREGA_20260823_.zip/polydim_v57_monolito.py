"""
POLYDIM V57 MONOLITO DE CERTIFICACIÓN MATEMÁTICA E ISOMÉTRICA (SOTA 2026)
Consolida todas las comprobaciones de inestabilidad, invarianza e isometría en D >= 10,000.
"""

import sys
import jax
import jax.numpy as jnp
import numpy as np

from polydim import (
    SiliconContract,
    configure_runtime,
    PMTPHeader,
    PMTPSharedMemoryBuffer,
    PolydimArenaAllocator,
    PMTPConsistencyError,
    PMTPProtocolError,
    GeodesicKernels,
    HouseholderReflection,
    OrthogonalProjector,
    SkewLowRankUpdate,
    assert_isometry
)

def run_v57_mathematical_certification():
    print("="*75)
    print("POLYDIM V57 SOTA: CERTIFICACIÓN ISOMÉTRICA & AUDITORÍA DE ISOMETRÍA")
    print("="*75)
    
    # 1. Configuración de Silicio
    configure_runtime(enable_x64=True)
    silicon = SiliconContract.inspect()
    print(f"[+] Silicio: {silicon['platform']} | Dispositivos: {silicon['device_count']} | Cores CPU: {silicon['cpu_cores']} | x64: {silicon['x64_enabled']}")
    print(f"[+] Nota de Silicio: {silicon['sharding_note']}")
    
    # 2. Warm-up de trazado JIT
    SiliconContract.warmup(GeodesicKernels, dim=1000)
    print("[+] Warm-Up JIT Multi-Dispositivo Completado.")

    # 3. Comprobación P0.1: Exp_x(0) = x y Jacobiano dExp_x/dv(0) = I sin NaN
    x0 = jnp.array([1.0, 0.0, 0.0, 0.0], dtype=jnp.float64)
    v0 = jnp.zeros_like(x0)
    exp_zero = GeodesicKernels.exp_map(x0, v0)
    assert jnp.allclose(exp_zero, x0), "Exp_x(0) != x!"
    
    jac_fn = jax.jacfwd(lambda tangent: GeodesicKernels.exp_map(x0, tangent))
    jac_at_zero = jac_fn(v0)
    assert not jnp.isnan(jac_at_zero).any(), "Jacobiano de Exp_x(0) contiene NaN!"
    print("[P0.1 PASSED] Exp_x(0) = x y Jacobiano d(Exp_x)/dv(0) sin NaN verificado (C^inf smoothness).")

    # 4. Comprobación P0.2: Log_x(x) = 0 exacto
    log_self = GeodesicKernels.log_map(x0, x0)
    assert jnp.allclose(log_self, 0.0), "Log_x(x) != 0!"
    print("[P0.2 PASSED] Log_x(x) = 0 exactamente (sin distancia fabricada).")

    # 5. Comprobación CLAUDE #15 & RED TEAM: Householder Reflection e Invarianza de Escala
    v_reflect = jnp.array([0.0, 1.0, 1.0, 0.0], dtype=jnp.float64)
    x_test = jnp.array([3.0, 4.0, 0.0, 0.0], dtype=jnp.float64)
    x_norm = x_test / jnp.linalg.norm(x_test)
    
    # Verificar invarianza de escala para v, 2v, 5v
    for scale in [1.0, 2.0, 5.0]:
        v_scaled = v_reflect * scale
        iso_ok = assert_isometry(HouseholderReflection.reflect, x_norm, v_scaled)
        assert iso_ok, f"Isometría falló para HouseholderReflection con vector v escalado x{scale}!"
    
    print("[CLAUDE #15 PASSED] Householder verificado con assert_isometry: Conserva norma Y producto interno <Hx, Hy> = <x, y> para vectores v escalados (v, 2v, 5v).")

    # 6. Comprobación P0.5b: Proyector Ortogonal idempotencia P^2 = P y P(x_in_span) = 0
    Q, _ = jnp.linalg.qr(jax.random.normal(jax.random.PRNGKey(42), (4, 2), dtype=jnp.float64))
    px = OrthogonalProjector.project_orthogonal(x_test, Q)
    ppx = OrthogonalProjector.project_orthogonal(px, Q)
    assert jnp.allclose(ppx, px), "OrthogonalProjector idempotence failed P^2 != P"
    
    x_in_span = Q[:, 0] * 5.0
    px_span = OrthogonalProjector.project_orthogonal(x_in_span, Q)
    assert jnp.allclose(px_span, 0.0, atol=1e-12), "OrthogonalProjector failed P(x_in_span) != 0"
    print("[P0.5b PASSED] Proyector Ortogonal lineal P^2 = P (Idempotente) y P(x_in_span) = 0 sin NaN.")

    # 7. Comprobación P0.3: SLERP composable en D=10,000 y precisión FP32 vs FP64
    q1 = jax.random.normal(jax.random.PRNGKey(10), (10000,), dtype=jnp.float32)
    q1 = q1 / jnp.linalg.norm(q1)
    q2 = jax.random.normal(jax.random.PRNGKey(11), (10000,), dtype=jnp.float32)
    q2 = q2 / jnp.linalg.norm(q2)
    
    err_l2 = GeodesicKernels.compute_l2_precision_error(q1, q2, 0.5)
    assert err_l2 < 1e-4, f"Error L2 de precisión FP32 excede umbral: {err_l2}"
    print(f"[P0.3 PASSED] SLERP composable verificado en D=10,000 | Error L2 FP32 vs FP64: {err_l2:.2e}.")

    # 8. Comprobación P0.4: PMTP V57 SWMR Seqlock de Lectura/Escritura Atómica
    shm_name = "test_polydim_v57_monolith"
    sample_data = np.arange(10000, dtype=np.float32)
    sample_bytes = sample_data.tobytes()

    with PMTPSharedMemoryBuffer(shm_name, dim=10000, mode='writer') as writer:
        writer.write_latent_bytes(sample_bytes)
        with PMTPSharedMemoryBuffer(shm_name, dim=10000, mode='reader') as reader:
            snapshot = reader.read_snapshot()
            assert np.array_equal(snapshot, np.frombuffer(sample_bytes, dtype=np.float32)), "PMTP V57 SWMR snapshot mismatch!"
    
    print(f"[P0.4 PASSED] PMTP V57 SWMR Seqlock de lectura/escritura atómica verificado bit a bit.")

    print("\n" + "="*75)
    print("POLYDIM V57 CERTIFICADO MATEMÁTICAMENTE & ISOMÉTRICAMENTE CON ÉXITO ABSOLUTO")
    print("="*75)

    # 9. Ejecutar la suite exhaustiva de tests V57 si está disponible
    try:
        from test_v57_suite import run_all_tests
        run_all_tests()
    except ImportError:
        try:
            from _HISTORICO.test_v57_suite import run_all_tests
            run_all_tests()
        except ImportError:
            pass

if __name__ == '__main__':
    run_v57_mathematical_certification()
