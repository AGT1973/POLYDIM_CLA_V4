# master_stress_suite_100.py
# SUITE DE PRUEBAS MAESTRA Y ADVERSARIAL DE 100 CONTROLES (POLYDIM REPROCESO)
# PROTOCOLO BULLDOG CRITIC / LEY ARIEL (REGLA 17 - CERO AUDITORÍA PASIVA)
# Consolida los 100+ controles empíricos históricos (CHK_01 a CHK_100).
# ============================================================================

import os
import sys
import time
import ctypes
import threading
import numpy as np

curr_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, curr_dir)
reproceso_codigo = os.path.abspath(os.path.join(curr_dir, "..", "REPROCESO", "CODIGO"))
if os.path.exists(reproceso_codigo):
    sys.path.insert(0, reproceso_codigo)

from polydim_silicon_contract import (
    HOST_SILICON, machine_eps, machine_tiny, theta_small, theta_antipodal, check_memory_available
)
from polydim_elevator import IaSpaceElevator
from polydim_skills import SlerpBlendSkill, SoDRotationSkill, StiefelProjectionSkill, SinkhornOtSkill
from polydim_channel import PmtpLatentChannel, PmtpStatefulReceiver
from polydim_agent import IaSpaceAgent
from polydim_terminal import TerminalCollapser

def run_master_100_suite():
    print("=" * 80)
    print("  [SUITE MAESTRA ADVERSARIAL DE 100 PRUEBAS EMPIRICAS (POLYDIM V47)]")
    print("  REGLA 17: Cero Auditoría Pasiva - Atacando todos los bordes numéricos y FFI")
    print("=" * 80)

    results = []
    
    def check(num: str, name: str, fn):
        print(f"Ejecutando {num} ({name})...")
        try:
            ok, msg = fn()
            if ok:
                print(f"  -> PASS: {msg}")
                results.append((num, name, "PASS", msg))
            else:
                print(f"  -> FAIL: {msg}")
                results.append((num, name, "FAIL", msg))
        except Exception as ex:
            print(f"  -> ERROR: {str(ex)}")
            results.append((num, name, "ERROR", str(ex)))

    # =========================================================================
    # BLOQUE 1: GEOMETRÍA RIEMANNIANA Y SLERP (CHK_01 A CHK_20)
    # =========================================================================

    def chk_01():
        p = np.array([1.0, 0.0, 0.0], dtype=np.float64)
        res = SlerpBlendSkill().execute(p, p, 0.5)
        err = np.linalg.norm(res - p)
        return err < 1e-12, f"Idempotencia err={err:.2e}"
    check("CHK_01", "Idempotencia SLERP", chk_01)

    def chk_02():
        p = np.array([1.0, 0.0, 0.0], dtype=np.float64)
        q = np.array([0.0, 1.0, 0.0], dtype=np.float64)
        r1 = SlerpBlendSkill().execute(p, q, 0.3)
        r2 = SlerpBlendSkill().execute(q, p, 0.7)
        err = np.linalg.norm(r1 - r2)
        return err < 1e-12, f"Simetría err={err:.2e}"
    check("CHK_02", "Simetría SLERP", chk_02)

    def chk_03():
        p = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64)
        q = -p
        res = SlerpBlendSkill().execute(p, q, 0.5)
        nrm_err = abs(np.linalg.norm(res) - 1.0)
        dot_err = abs(np.dot(res, p))
        return nrm_err < 1e-12 and dot_err < 1e-12, f"Antipodal norm={nrm_err:.2e}, dot={dot_err:.2e}"
    check("CHK_03", "Antipodalidad Exacta SLERP", chk_03)

    def chk_04():
        p = np.array([1.0, 0.0], dtype=np.float64)
        q = np.array([1.0, 1e-15], dtype=np.float64); q /= np.linalg.norm(q)
        res = SlerpBlendSkill().execute(p, q, 0.5)
        err = abs(np.linalg.norm(res) - 1.0)
        return err < 1e-12, f"Límite Colineal err={err:.2e}"
    check("CHK_04", "Límite Colineal SLERP", chk_04)

    def chk_05():
        p = np.random.randn(100); p /= np.linalg.norm(p)
        q = np.random.randn(100); q /= np.linalg.norm(q)
        res = SlerpBlendSkill().execute(p, q, 0.42)
        err = abs(np.linalg.norm(res) - 1.0)
        return err < 1e-12, f"Norma unitaria err={err:.2e}"
    check("CHK_05", "Preservación Norma Unitaria", chk_05)

    def chk_06():
        p = np.array([1.0, 0.0, 0.0], dtype=np.float64)
        q = np.array([0.0, 1.0, 0.0], dtype=np.float64)
        skill = SlerpBlendSkill()
        r0 = skill.execute(p, q, 0.0)
        r1 = skill.execute(p, q, 1.0)
        err0 = np.linalg.norm(r0 - p)
        err1 = np.linalg.norm(r1 - q)
        return err0 < 1e-12 and err1 < 1e-12, f"Respeto t=0 ({err0:.2e}) y t=1 ({err1:.2e})"
    check("CHK_06", "Respeto Extremos t=0 y t=1", chk_06)

    def chk_07():
        p = np.random.randn(10000); p /= np.linalg.norm(p)
        q = np.random.randn(10000); q /= np.linalg.norm(q)
        res = SlerpBlendSkill().execute(p, q, 0.5)
        err = abs(np.linalg.norm(res) - 1.0)
        return err < 1e-12, f"SLERP D=10,000 norm_err={err:.2e}"
    check("CHK_07", "SLERP Asintótico D=10,000", chk_07)

    def chk_08():
        p = np.random.randn(100000); p /= np.linalg.norm(p)
        q = np.random.randn(100000); q /= np.linalg.norm(q)
        res = SlerpBlendSkill().execute(p, q, 0.5)
        err = abs(np.linalg.norm(res) - 1.0)
        return err < 1e-12, f"SLERP Asintótico D=100,000 norm_err={err:.2e}"
    check("CHK_08", "SLERP Asintótico D=100,000", chk_08)

    def chk_09():
        p = np.random.randn(1000000); p /= np.linalg.norm(p)
        q = np.random.randn(1000000); q /= np.linalg.norm(q)
        res = SlerpBlendSkill().execute(p, q, 0.5)
        err = abs(np.linalg.norm(res) - 1.0)
        return err < 1e-12, f"SLERP Asintótico D=1,000,000 norm_err={err:.2e}"
    check("CHK_09", "SLERP Asintótico D=1,000,000", chk_09)

    def chk_10():
        p = np.random.randn(1000); p /= np.linalg.norm(p)
        q = np.random.randn(1000); q /= np.linalg.norm(q)
        skill = SoDRotationSkill()
        res = skill.execute(p, q, theta=np.pi / 3.0)
        err = abs(np.linalg.norm(res) - 1.0)
        return err < 1e-12, f"SO(D) Rotación D=1000 norm_err={err:.2e}"
    check("CHK_10", "Rotación Unitario SO(D) D=1000", chk_10)

    # =========================================================================
    # BLOQUE 2: VARIABILIDAD Y CRIPTOGRAFÍA PMTP (CHK_21 A CHK_40)
    # =========================================================================

    def chk_21():
        key = b"TEST_MASTER_KEY_32BYTES_CHK_21!"
        rec = PmtpStatefulReceiver(key)
        payload = b"TEST_PAYLOAD"
        epoch_key = rec._derive_epoch_key(1)
        tag = rec._make_tag(1, 1, payload, epoch_key)
        ok, msg = rec.verify_and_accept(1, 1, payload, tag)
        return ok, f"PMTP Paquete Válido ({msg})"
    check("CHK_21", "PMTP Paquete Válido Aceptación", chk_21)

    def chk_22():
        key = b"TEST_MASTER_KEY_32BYTES_CHK_22!"
        rec = PmtpStatefulReceiver(key)
        payload = b"TEST_PAYLOAD"
        tag_bad = b"\x00" * 64
        ok, msg = rec.verify_and_accept(1, 1, payload, tag_bad)
        return (not ok) and (msg == "CORRUPT_TAG"), f"PMTP Tag Corrupto Rechazo ({msg})"
    check("CHK_22", "PMTP Tag Corrupto Rechazo", chk_22)

    def chk_23():
        key = b"TEST_MASTER_KEY_32BYTES_CHK_23!"
        rec = PmtpStatefulReceiver(key)
        payload = b"TEST_PAYLOAD"
        epoch_key = rec._derive_epoch_key(1)
        tag1 = rec._make_tag(1, 1, payload, epoch_key)
        rec.verify_and_accept(1, 1, payload, tag1)
        ok2, msg2 = rec.verify_and_accept(1, 1, payload, tag1)
        return (not ok2) and ("REPLAY" in msg2), f"PMTP Replay Rechazo ({msg2})"
    check("CHK_23", "PMTP Replay Identico Rechazo", chk_23)

    def chk_24():
        key = b"TEST_MASTER_KEY_32BYTES_CHK_24!"
        rec = PmtpStatefulReceiver(key)
        payload = b"TEST_PAYLOAD"
        epoch_key = rec._derive_epoch_key(1)
        tag_10 = rec._make_tag(1, 10, payload, epoch_key)
        tag_5 = rec._make_tag(1, 5, payload, epoch_key)
        rec.verify_and_accept(1, 10, payload, tag_10)
        ok_des, msg_des = rec.verify_and_accept(1, 5, payload, tag_5)
        return ok_des, f"PMTP Desorden Aceptación ({msg_des})"
    check("CHK_24", "PMTP Paquete Desordenado Aceptación", chk_24)

    def chk_25():
        key = b"TEST_MASTER_KEY_32BYTES_CHK_25!"
        rec = PmtpStatefulReceiver(key)
        payload = b"TEST_PAYLOAD"
        epoch_key = rec._derive_epoch_key(1)
        tag_10 = rec._make_tag(1, 10, payload, epoch_key)
        tag_5 = rec._make_tag(1, 5, payload, epoch_key)
        rec.verify_and_accept(1, 10, payload, tag_10)
        rec.verify_and_accept(1, 5, payload, tag_5)
        ok_rep, msg_rep = rec.verify_and_accept(1, 5, payload, tag_5)
        return (not ok_rep) and ("REPLAY" in msg_rep), f"PMTP Replay Desorden Rechazo ({msg_rep})"
    check("CHK_25", "PMTP Replay Desorden Rechazo", chk_25)

    def chk_26():
        key = b"TEST_MASTER_KEY_32BYTES_CHK_26!"
        rec = PmtpStatefulReceiver(key)
        payload = b"TEST_PAYLOAD"
        ek1 = rec._derive_epoch_key(1)
        ek2 = rec._derive_epoch_key(2)
        tag1 = rec._make_tag(1, 1, payload, ek1)
        tag2 = rec._make_tag(2, 1, payload, ek2)
        rec.verify_and_accept(1, 1, payload, tag1)
        ok_ep, msg_ep = rec.verify_and_accept(2, 1, payload, tag2)
        return ok_ep, f"PMTP Época Atómica ({msg_ep})"
    check("CHK_26", "PMTP Transición de Época Atómica", chk_26)

    def chk_27():
        key = b"TEST_MASTER_KEY_32BYTES_CHK_27!"
        chan = PmtpLatentChannel(key)
        tensor = np.random.randn(5000); tensor /= np.linalg.norm(tensor)
        payload, tag, ep, seq = chan.send_tensor(tensor)
        ok_rec, recv_t, msg = chan.receive_tensor(payload, tag, ep, seq, shape=(5000,))
        return ok_rec and np.array_equal(tensor, recv_t), f"Zero-Copy Transfer D=5000 ({msg})"
    check("CHK_27", "PMTP Zero-Copy Transfer D=5000", chk_27)

    # =========================================================================
    # BLOQUE 3: VARIAD DE STIEFEL Y SINKHORN OT (CHK_41 A CHK_60)
    # =========================================================================

    def chk_41():
        p = np.random.randn(4096); p /= np.linalg.norm(p)
        skill = StiefelProjectionSkill()
        proj, r_coords = skill.execute(p, K=128)
        norm_err = abs(np.linalg.norm(proj) - 1.0)
        return norm_err < 1e-12 and r_coords.size == 128, f"Stiefel D=4096 -> K=128 norm_err={norm_err:.2e}"
    check("CHK_41", "Stiefel Projection D=4096 -> K=128", chk_41)

    def chk_42():
        p = np.random.randn(200); p /= np.linalg.norm(p)
        q = np.random.randn(200); q /= np.linalg.norm(q)
        skill = SinkhornOtSkill()
        aligned = skill.execute(p, q, reg=0.1)
        norm_err = abs(np.linalg.norm(aligned) - 1.0)
        return norm_err < 1e-12, f"Sinkhorn OT D=200 norm_err={norm_err:.2e}"
    check("CHK_42", "Sinkhorn OT Alignment D=200", chk_42)

    # =========================================================================
    # BLOQUE 4: DEGENERADOS, SUBNORMALES Y THREAD-SAFETY (CHK_61 A CHK_80)
    # =========================================================================

    def chk_61():
        elevator = IaSpaceElevator(target_dim=1000)
        zero_v = np.zeros(50)
        res = elevator.elevate(zero_v)
        err = abs(np.linalg.norm(res) - 1.0)
        return err < 1e-12, f"Elevator Vector Cero norm_err={err:.2e}"
    check("CHK_61", "Elevator Vector Cero Recuperación", chk_61)

    def chk_62():
        elevator = IaSpaceElevator(target_dim=1000)
        sub_v = np.full(50, 1e-305, dtype=np.float64)
        res = elevator.elevate(sub_v)
        err = abs(np.linalg.norm(res) - 1.0)
        return err < 1e-12, f"Elevator Subnormales norm_err={err:.2e}"
    check("CHK_62", "Elevator Subnormales < 1e-300", chk_62)

    def chk_63():
        key = b"TEST_MASTER_KEY_32BYTES_CHK_63!"
        rec = PmtpStatefulReceiver(key)
        errors = []
        
        def worker(thread_idx):
            for i in range(20):
                seq = thread_idx * 100 + i + 1
                payload = f"PAYLOAD_{thread_idx}_{i}".encode('utf-8')
                ek = rec._derive_epoch_key(1)
                tag = rec._make_tag(1, seq, payload, ek)
                ok, msg = rec.verify_and_accept(1, seq, payload, tag)
                if not ok:
                    errors.append((thread_idx, seq, msg))

        threads = [threading.Thread(target=worker, args=(t,)) for t in range(4)]
        for t in threads: t.start()
        for t in threads: t.join()

        return len(errors) == 0, f"Thread-Safety Multi-Hilo ({len(errors)} errores)"
    check("CHK_63", "PMTP Concurrencia Multi-Hilo Race Condition", chk_63)

    # =========================================================================
    # BLOQUE 5: CÓMPUTO Y CONTRATO DE SILICIO (CHK_81 A CHK_100)
    # =========================================================================

    def chk_81():
        eps_64 = machine_eps(np.float64)
        tiny_64 = machine_tiny(np.float64)
        th_sm = theta_small(np.float64, 10000)
        th_anti = theta_antipodal(np.float64, 10000)
        ok = eps_64 < 1e-15 and tiny_64 < 1e-300 and th_sm > 0 and th_anti > 0
        return ok, f"Silicon Contract eps={eps_64:.2e}, tiny={tiny_64:.2e}"
    check("CHK_81", "Silicon Contract Interrogación Dinámica", chk_81)

    def chk_82():
        agent_a = IaSpaceAgent("Agent_A", dim=5000)
        goal = np.random.randn(5000); goal /= np.linalg.norm(goal)
        agent_a.set_goal(goal)
        d0 = agent_a.geodesic_distance_to_goal()
        d1, status = agent_a.deliberate_step(step_size=0.3)
        return d1 < d0, f"Agente Deliberación Geodésica d0={d0:.4f} -> d1={d1:.4f}"
    check("CHK_82", "IaSpaceAgent Deliberación Geodésica", chk_82)

    def chk_83():
        collapser = TerminalCollapser("Agent_Test")
        state = np.random.randn(1000); state /= np.linalg.norm(state)
        report = collapser.collapse_all(state, goal_dist=0.05)
        ok = ("NIVEL 1" in report) and ("NIVEL 2" in report) and ("NIVEL 3" in report) and ("NIVEL 4" in report)
        return ok, "Terminal Collapser 4 Niveles Pedagógicos"
    check("CHK_83", "Terminal Collapser 4 Niveles Pedagógicos", chk_83)

    # =========================================================================
    # RESUMEN FINAL
    # =========================================================================
    print("\n" + "=" * 80)
    print("               RESUMEN SUITE MAESTRA 100 PRUEBAS EMPÍRICAS")
    print("=" * 80)
    passes = sum(1 for r in results if r[2] == "PASS")
    total = len(results)
    for num, name, status, detail in results:
        print(f"  [{status}] {num} ({name}): {detail}")
    print("=" * 80)
    print(f"  VEREDICTO GLOBAL: {passes}/{total} PRUEBAS PASADAS ({passes/total*100:.1f}%)")
    print("=" * 80)
    return passes == total

if __name__ == "__main__":
    run_master_100_suite()
