import os
# Configurar variables de entorno antes de importar JAX para asegurar que se lean correctamente (Fix #5)
os.environ['JAX_ENABLE_X64'] = 'True'
os.environ['XLA_PYTHON_CLIENT_MEM_FRACTION'] = '0.85'

# Cache persistente de compilación de JAX (Fix #88)
cache_dir = os.environ.get("JAX_COMPILATION_CACHE_DIR")
if not cache_dir:
    cache_dir = os.path.expanduser("~/.cache/jax_polydim")
os.makedirs(cache_dir, exist_ok=True)
os.environ["JAX_COMPILATION_CACHE_DIR"] = cache_dir

import sys
import ctypes
import uuid
import struct
import hashlib
import time
import subprocess
import atexit
import warnings
import socket
import threading
import tempfile
import hmac
from concurrent.futures import ThreadPoolExecutor
from queue import Queue, Full
import platform
import shutil
import numpy as np
import ml_dtypes

import jax
import jax.numpy as jnp
from jax import jit, vmap

# Confirmación defensiva de X64 habilitado
if not jax.config.x64_enabled:
    warnings.warn(
        "POLYDIM: JAX_ENABLE_X64 no está activo. "
        "Asegúrate de importar polydim antes de cualquier otro módulo de JAX."
    )

# Actualizar el cache de compilación de JAX
try:
    jax.config.update("jax_compilation_cache_dir", cache_dir)
except Exception:
    pass

# =====================================================================
# 1. FUENTES NATIVAS EMBEBIDAS (Rust + C++ con alineamiento y protección)
# =====================================================================

RUST_SOURCE = """use std::slice;
use std::panic;

#[no_mangle]
pub unsafe extern "C" fn polydim_rust_householder_reflect(
    x_ptr: *const f64,
    v_ptr: *const f64,
    out_ptr: *mut f64,
    dim: usize,
) -> i32 {
    let result = panic::catch_unwind(|| {
        if x_ptr.is_null() || v_ptr.is_null() || out_ptr.is_null() || dim == 0 {
            return -1i32;
        }
        
        let align = std::mem::align_of::<f64>();
        if (x_ptr as usize) % align != 0 || (v_ptr as usize) % align != 0 || (out_ptr as usize) % align != 0 {
            return -1i32;
        }
        
        // checked_mul para prevenir desbordamiento de enteros (Vector 4)
        let bytes = match dim.checked_mul(std::mem::size_of::<f64>()) {
            Some(b) => b,
            None => return -4i32,
        };
        
        let o = out_ptr as usize..out_ptr as usize + bytes;
        let x = x_ptr as usize..x_ptr as usize + bytes;
        let v = v_ptr as usize..v_ptr as usize + bytes;
        if x.start < o.end && o.start < x.end { return -2; }
        if v.start < o.end && o.start < v.end { return -2; }
        
        let x = slice::from_raw_parts(x_ptr, dim);
        let v = slice::from_raw_parts(v_ptr, dim);
        let out = slice::from_raw_parts_mut(out_ptr, dim);
        
        let v_norm_sq: f64 = v.iter().map(|&a| a * a).sum();
        if v_norm_sq < 1e-30 {
            out.copy_from_slice(x);
            return 0;
        }
        let dot_xv: f64 = x.iter().zip(v.iter()).map(|(&a, &b)| a * b).sum();
        let factor = 2.0 * dot_xv / v_norm_sq;
        
        for i in 0..dim {
            out[i] = x[i] - factor * v[i];
        }
        0
    });
    
    match result {
        Ok(code) => code,
        Err(_) => -1,
    }
}

#[no_mangle]
pub unsafe extern "C" fn polydim_rust_scrub_subnormals(
    data_ptr: *mut f64,
    dim: usize,
) -> i32 {
    let result = panic::catch_unwind(|| {
        if data_ptr.is_null() { return -1i32; }
        if (data_ptr as usize) % std::mem::align_of::<f64>() != 0 { return -1i32; }
        if dim == 0 { return 0; }
        
        let data = slice::from_raw_parts_mut(data_ptr, dim);
        for x in data.iter_mut() {
            if x.is_subnormal() {
                *x = 0.0;
            }
        }
        0
    });
    
    match result {
        Ok(code) => code,
        Err(_) => -1,
    }
}
"""

CPP_SOURCE = """#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>

#ifdef _WIN32
#define EXPORT_SYM __declspec(dllexport)
#else
#define EXPORT_SYM __attribute__((visibility("default")))
#endif

extern "C" {

// Scrub portable de subnormales mediante manipulación de bits (Fix V74.ARM64)
EXPORT_SYM int polydim_cpp_scrub_subnormals(double* data, size_t size) {
    if (!data) return -1;
    for (size_t i = 0; i < size; ++i) {
        uint64_t bits;
        std::memcpy(&bits, &data[i], sizeof(double));
        uint64_t exp = bits & 0x7FF0000000000000ULL;
        uint64_t mant = bits & 0x000FFFFFFFFFFFFFULL;
        if (exp == 0 && mant != 0) {
            data[i] = 0.0;
        }
    }
    return 0;
}

EXPORT_SYM int polydim_cpp_householder_reflect(const double* x, const double* v, double* out, size_t dim) {
    if (!x || !v || !out || dim == 0) return -1;
    
    // Checked mul para evitar desbordamiento en C++ (Vector 4)
    if (dim > (SIZE_MAX / sizeof(double))) return -4;
    
    // Validación física de alineamiento a 8 bytes (Vector 19)
    if (reinterpret_cast<uintptr_t>(x) % 8 != 0 ||
        reinterpret_cast<uintptr_t>(v) % 8 != 0 ||
        reinterpret_cast<uintptr_t>(out) % 8 != 0) {
        return -3;
    }
    
    const size_t bytes = dim * sizeof(double);
    const uintptr_t o = reinterpret_cast<uintptr_t>(out);
    const uintptr_t a = reinterpret_cast<uintptr_t>(x);
    const uintptr_t b = reinterpret_cast<uintptr_t>(v);
    
    // v/out deben estar separados, pero x/out se permiten solapar porque memmove lo soporta
    if (b < o + bytes && o < b + bytes) return -2;
    
    double v_norm_sq = 0.0;
    for (size_t i = 0; i < dim; ++i) {
        v_norm_sq += v[i] * v[i];
    }
    if (v_norm_sq < 1e-30) {
        std::memmove(out, x, bytes);
        return 0;
    }
    double dot_xv = 0.0;
    for (size_t i = 0; i < dim; ++i) {
        dot_xv += x[i] * v[i];
    }
    double factor = 2.0 * dot_xv / v_norm_sq;
    for (size_t i = 0; i < dim; ++i) {
        out[i] = x[i] - factor * v[i];
    }
    return 0;
}

}
"""

# =====================================================================
# 2. PUENTE FFI CON DUAL-KERNEL ORACLE Y CACHÉ DE FUENTES (Zero-Waste)
# =====================================================================

class NativeFFIBridge:
    _initialized = False
    _rust_dll = None
    _cpp_dll = None
    _preferred = None  # 'cpp' or 'rust'
    _temp_files = []
    _init_lock = threading.Lock()

    @classmethod
    def cleanup(cls):
        # Liberación determinista de librerías nativas (Fix #89 / FreeLibrary)
        if platform.system() == "Windows":
            import _ctypes
            if cls._rust_dll and hasattr(cls._rust_dll, '_handle') and cls._rust_dll._handle:
                try:
                    _ctypes.FreeLibrary(cls._rust_dll._handle)
                except:
                    pass
            if cls._cpp_dll and hasattr(cls._cpp_dll, '_handle') and cls._cpp_dll._handle:
                try:
                    _ctypes.FreeLibrary(cls._cpp_dll._handle)
                except:
                    pass
        else:
            # POSIX dlclose explícito para evitar leaks de memoria virtual
            try:
                _dlclose = ctypes.CDLL(None).dlclose
                _dlclose.argtypes = [ctypes.c_void_p]
                _dlclose.restype = ctypes.c_int
                if cls._rust_dll and hasattr(cls._rust_dll, '_handle') and cls._rust_dll._handle:
                    _dlclose(cls._rust_dll._handle)
                if cls._cpp_dll and hasattr(cls._cpp_dll, '_handle') and cls._cpp_dll._handle:
                    _dlclose(cls._cpp_dll._handle)
            except:
                pass
            
        for path in cls._temp_files:
            try:
                if os.path.exists(path):
                    os.unlink(path)
            except:
                pass
        cls._temp_files.clear()

    @classmethod
    def _get_preferred(cls):
        with cls._init_lock:
            if cls._cpp_dll is not None:
                return 'cpp'
            if cls._rust_dll is not None:
                return 'rust'
            return None

    @classmethod
    def initialize(cls):
        if cls._initialized:
            return
        with cls._init_lock:
            if cls._initialized:
                return
            atexit.register(cls.cleanup)
            
            # Caching de compilación basado en hashes de los fuentes (Fix V74.ColdStart)
            source_content = RUST_SOURCE + CPP_SOURCE
            source_hash = hashlib.sha256(source_content.encode("utf-8")).hexdigest()[:16]
            
            out_dir = os.path.join(tempfile.gettempdir(), "POLYDIM_EINSOF_V74")
            os.makedirs(out_dir, exist_ok=True)
            
            rust_path = os.path.join(out_dir, f"polydim_kernel_{source_hash}.rs")
            cpp_path = os.path.join(out_dir, f"polydim_kernel_{source_hash}.cpp")
            
            prefix = "" if platform.system() == "Windows" else "lib"
            ext = ".dll" if platform.system() == "Windows" else ".so"
            rust_dll = os.path.join(out_dir, f"{prefix}polydim_rust_{source_hash}{ext}")
            cpp_dll = os.path.join(out_dir, f"{prefix}polydim_cpp_{source_hash}{ext}")
            
            cls._temp_files.extend([rust_path, cpp_path, rust_dll, cpp_dll])
            
            # Intentar cargar Rust FFI ya compilado
            if os.path.exists(rust_dll):
                try:
                    cls._rust_dll = ctypes.CDLL(rust_dll)
                    cls._rust_dll.polydim_rust_householder_reflect.argtypes = [
                        ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
                        ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                    ]
                    cls._rust_dll.polydim_rust_householder_reflect.restype = ctypes.c_int
                    cls._rust_dll.polydim_rust_scrub_subnormals.argtypes = [
                        ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                    ]
                    cls._rust_dll.polydim_rust_scrub_subnormals.restype = ctypes.c_int
                    cls._preferred = 'rust'
                except:
                    cls._rust_dll = None
            
            if cls._rust_dll is None:
                try:
                    with open(rust_path, "w", encoding="utf-8") as f:
                        f.write(RUST_SOURCE)
                    
                    rustc = shutil.which("rustc")
                    if not rustc:
                        if platform.system() == "Windows":
                            rustc = os.path.expanduser("~/.cargo/bin/rustc.exe")
                        else:
                            rustc = os.path.expanduser("~/.cargo/bin/rustc")
                    if not rustc or not os.path.exists(rustc):
                        rustc = "rustc"
                        
                    subprocess.run(
                        [rustc, "--edition", "2021", "--crate-type", "cdylib", "-O", "-C", "debuginfo=0", "-o", rust_dll, rust_path],
                        check=True, capture_output=True, timeout=30
                    )
                    cls._rust_dll = ctypes.CDLL(rust_dll)
                    cls._rust_dll.polydim_rust_householder_reflect.argtypes = [
                        ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
                        ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                    ]
                    cls._rust_dll.polydim_rust_householder_reflect.restype = ctypes.c_int
                    cls._rust_dll.polydim_rust_scrub_subnormals.argtypes = [
                        ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                    ]
                    cls._rust_dll.polydim_rust_scrub_subnormals.restype = ctypes.c_int
                    cls._preferred = 'rust'
                except Exception as e:
                    warnings.warn(f"Compilación de Rust FFI falló (Fallback a JAX activo): {e}")

            # Intentar cargar C++ FFI ya compilado
            if os.path.exists(cpp_dll):
                try:
                    cls._cpp_dll = ctypes.CDLL(cpp_dll)
                    cls._cpp_dll.polydim_cpp_householder_reflect.argtypes = [
                        ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
                        ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                    ]
                    cls._cpp_dll.polydim_cpp_householder_reflect.restype = ctypes.c_int
                    cls._cpp_dll.polydim_cpp_scrub_subnormals.argtypes = [
                        ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                    ]
                    cls._cpp_dll.polydim_cpp_scrub_subnormals.restype = ctypes.c_int
                    cls._preferred = 'cpp'
                except:
                    cls._cpp_dll = None

            if cls._cpp_dll is None:
                try:
                    with open(cpp_path, "w", encoding="utf-8") as f:
                        f.write(CPP_SOURCE)
                        
                    cxx = shutil.which("g++") or shutil.which("clang++") or shutil.which("c++")
                    args = [cxx, "-O2", "-shared", "-fPIC", "-o", cpp_dll, cpp_path] if cxx else None
                    if args is None:
                        cl = shutil.which("cl")
                        if cl:
                            args = [cl, "/nologo", "/LD", "/O2", f"/Fe:{cpp_dll}", cpp_path]
                    
                    if args is not None:
                        subprocess.run(args, check=True, capture_output=True, timeout=30)
                        cls._cpp_dll = ctypes.CDLL(cpp_dll)
                        cls._cpp_dll.polydim_cpp_householder_reflect.argtypes = [
                            ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
                            ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                        ]
                        cls._cpp_dll.polydim_cpp_householder_reflect.restype = ctypes.c_int
                        cls._cpp_dll.polydim_cpp_scrub_subnormals.argtypes = [
                            ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                        ]
                        cls._cpp_dll.polydim_cpp_scrub_subnormals.restype = ctypes.c_int
                        cls._preferred = 'cpp'
                except Exception as e:
                    warnings.warn(f"Compilación de C++ FFI falló: {e}")
                    
            cls._initialized = True

    @classmethod
    def _ffi_householder_rows(cls, x2d: np.ndarray, v2d: np.ndarray) -> np.ndarray:
        preferred = cls._get_preferred()
        dll = cls._cpp_dll if preferred == 'cpp' else cls._rust_dll
        out = np.empty_like(x2d)
        dim = x2d.shape[-1]
        
        fn = dll.polydim_cpp_householder_reflect if preferred == 'cpp' else dll.polydim_rust_householder_reflect
            
        for i in range(x2d.shape[0]):
            # Chequeo físico de alineación de punteros
            ptr_x = x2d[i].ctypes.data
            ptr_v = v2d[i].ctypes.data
            ptr_out = out[i].ctypes.data
            
            # Si alguno no está alineado a 8 bytes, hacemos copia alineada
            if ptr_x % 8 != 0 or ptr_v % 8 != 0 or ptr_out % 8 != 0:
                x_aligned = np.copy(x2d[i])
                v_aligned = np.copy(v2d[i])
                out_aligned = np.empty_like(x2d[i])
                ret = fn(
                    x_aligned.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                    v_aligned.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                    out_aligned.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                    ctypes.c_size_t(dim),
                )
                out[i] = out_aligned
            else:
                ret = fn(
                    x2d[i].ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                    v2d[i].ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                    out[i].ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                    ctypes.c_size_t(dim),
                )
            if ret != 0:
                return None
        return out

    @classmethod
    def householder_reflect(cls, x: jnp.ndarray, v: jnp.ndarray) -> jnp.ndarray:
        cls.initialize()
        
        def jax_fallback():
            denom = jnp.maximum(jnp.sum(v * v, axis=-1, keepdims=True), 1e-30)
            return x - 2.0 * jnp.sum(x * v, axis=-1, keepdims=True) / denom * v
            
        # Evitar fallos de conversión de JIT tracers en la frontera FFI (Vector FFI context)
        if isinstance(x, jax.core.Tracer) or isinstance(v, jax.core.Tracer):
            return jax_fallback()

        x.block_until_ready()
        v.block_until_ready()

        if x.ndim != 1 or v.ndim != 1:
            if cls._rust_dll is None and cls._cpp_dll is None:
                return jax_fallback()
            x_np = np.ascontiguousarray(jax.device_get(x).astype(np.float64))
            v_np = np.ascontiguousarray(jax.device_get(v).astype(np.float64))
            x2d = x_np.reshape(-1, x_np.shape[-1])
            v2d = v_np.reshape(-1, v_np.shape[-1]) if v_np.ndim > 1 else np.ascontiguousarray(np.broadcast_to(v_np, x2d.shape))
            
            if v2d.shape != x2d.shape:
                return jax_fallback()
                
            out = cls._ffi_householder_rows(x2d, v2d)
            if out is None:
                return jax_fallback()
            return jax.device_put(jnp.array(out.reshape(x.shape), dtype=x.dtype))

        if cls._rust_dll is None and cls._cpp_dll is None:
            return jax_fallback()
            
        x_np = np.ascontiguousarray(jax.device_get(x).astype(np.float64))
        v_np = np.ascontiguousarray(jax.device_get(v).astype(np.float64))
        dim = x_np.size
        out_np = np.zeros_like(x_np)
        
        # Validar alineación
        if x_np.ctypes.data % 8 != 0: x_np = np.copy(x_np)
        if v_np.ctypes.data % 8 != 0: v_np = np.copy(v_np)
        if out_np.ctypes.data % 8 != 0: out_np = np.copy(out_np)
        
        preferred = cls._get_preferred()
        dll = cls._cpp_dll if preferred == 'cpp' else cls._rust_dll
        if preferred == 'cpp':
            ret = dll.polydim_cpp_householder_reflect(
                x_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                v_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                out_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                ctypes.c_size_t(dim)
            )
        else:
            ret = dll.polydim_rust_householder_reflect(
                x_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                v_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                out_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                ctypes.c_size_t(dim)
            )
            
        if ret != 0:
            return jax_fallback()
        return jax.device_put(jnp.array(out_np, dtype=x.dtype))

    @classmethod
    def scrub_subnormals(cls, x: jnp.ndarray) -> jnp.ndarray:
        cls.initialize()
        
        def numpy_fallback(arr):
            tiny = np.finfo(arr.dtype).tiny
            mask = (arr != 0.0) & (np.abs(arr) < tiny)
            arr[mask] = 0.0
            return arr

        if isinstance(x, jax.core.Tracer):
            # Para tracers bajo JIT, resolvemos de manera pura y diferenciable
            tiny = jnp.finfo(x.dtype).tiny
            return jnp.where(jnp.abs(x) < tiny, 0.0, x)

        x.block_until_ready()
        x_np = np.ascontiguousarray(jax.device_get(x)).copy()
        
        if x_np.dtype == np.float64:
            preferred = cls._get_preferred()
            dll = cls._cpp_dll if preferred == 'cpp' else cls._rust_dll
            if dll is not None:
                if x_np.ctypes.data % 8 != 0:
                    x_np = np.copy(x_np)
                if preferred == 'cpp':
                    dll.polydim_cpp_scrub_subnormals(
                        x_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                        ctypes.c_size_t(x_np.size)
                    )
                else:
                    dll.polydim_rust_scrub_subnormals(
                        x_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                        ctypes.c_size_t(x_np.size)
                    )
                return jax.device_put(jnp.array(x_np, dtype=x.dtype))
        
        numpy_fallback(x_np)
        return jax.device_put(jnp.array(x_np, dtype=x.dtype))

# =====================================================================
# 3. NÚCLEO MATEMÁTICO SOTA V74 (Clifford e Einsum Corregidos)
# =====================================================================

def safe_dot(a: jnp.ndarray, b: jnp.ndarray, keepdims: bool = False) -> jnp.ndarray:
    if not jnp.issubdtype(a.dtype, jnp.inexact):
        a = a.astype(jnp.float32)
    if not jnp.issubdtype(b.dtype, jnp.inexact):
        b = b.astype(jnp.float32)
    return jnp.sum(a * b, axis=-1, keepdims=keepdims)

def safe_norm(x: jnp.ndarray, axis=-1, keepdims: bool = True) -> jnp.ndarray:
    if not jnp.issubdtype(x.dtype, jnp.inexact):
        x = x.astype(jnp.float32)
        
    axis_t = (axis,) if isinstance(axis, int) else tuple(axis)
    scale = jnp.max(jnp.abs(x), axis=axis_t, keepdims=True)
    has_inf = jnp.any(jnp.isinf(x), axis=axis_t, keepdims=keepdims)
    
    safe_scale = jnp.where(scale == 0.0, 1.0, scale)
    scaled_x = x / safe_scale
    if x.dtype.kind == 'c':
        sq_sum = jnp.sum((scaled_x * jnp.conj(scaled_x)).real, axis=axis_t, keepdims=keepdims)
    else:
        sq_sum = jnp.sum(scaled_x * scaled_x, axis=axis_t, keepdims=keepdims)
        
    norm = scale * jnp.sqrt(jnp.where(scale == 0.0, 1.0, sq_sum))
    norm = jnp.where(scale == 0.0, 0.0, norm)
    norm = jnp.where(has_inf, jnp.inf, norm)
    
    if not keepdims: 
        norm = jnp.squeeze(norm, axis=axis_t)
    return norm.astype(x.dtype)

class GeodesicKernels:
    
    @staticmethod
    @jit
    def exp_map(x: jnp.ndarray, v: jnp.ndarray) -> jnp.ndarray:
        eps = jnp.finfo(x.dtype).eps
        safe_x_norm = jnp.maximum(safe_norm(x, keepdims=True), eps)
        x_unit = x / safe_x_norm
        
        dot_vx = safe_dot(v, x_unit, keepdims=True)
        v_tangent = v - dot_vx * x_unit
        v_tangent = v_tangent - safe_dot(v_tangent, x_unit, keepdims=True) * x_unit
        
        v_sq = jnp.maximum(safe_dot(v_tangent, v_tangent, keepdims=True), 0.0)
        norm_v = jnp.sqrt(v_sq)
        
        cos_t = jnp.cos(norm_v)
        sinc_t = jnp.where(norm_v == 0.0, 1.0, jnp.sin(norm_v) / jnp.maximum(norm_v, eps))
        result = cos_t * x_unit + sinc_t * v_tangent
        
        return result / jnp.maximum(safe_norm(result, keepdims=True), eps)

    @staticmethod
    @jit
    def _log_map_unit(xu: jnp.ndarray, yu: jnp.ndarray) -> jnp.ndarray:
        eps = jnp.finfo(xu.dtype).eps
        dot = jnp.clip(safe_dot(xu, yu, keepdims=True), -1.0, 1.0)
        proj = yu - dot * xu
        s = jnp.sqrt(jnp.sum(proj * proj, axis=-1, keepdims=True))
        theta = jnp.atan2(s, dot)
        safe_s = jnp.where(s > eps, s, 1.0)
        return (theta / safe_s) * proj

    @staticmethod
    @jit
    def log_map(x: jnp.ndarray, y: jnp.ndarray) -> jnp.ndarray:
        eps = jnp.finfo(x.dtype).eps
        xu = x / jnp.maximum(safe_norm(x, keepdims=True), eps)
        yu = y / jnp.maximum(safe_norm(y, keepdims=True), eps)
        
        dim = x.shape[-1]
        tol = 10.0 * eps * jnp.sqrt(jnp.maximum(dim, 1))
        dot = jnp.clip(safe_dot(xu, yu, keepdims=True), -1.0, 1.0)
        
        is_identity = dot >= (1.0 - tol)
        is_antipodal = dot <= (-1.0 + tol)
        degenerate = is_identity | is_antipodal
        
        log_normal = GeodesicKernels._log_map_unit(xu, yu)
        
        e0 = jnp.zeros_like(xu).at[..., 0].set(1.0)
        e1 = jnp.zeros_like(xu).at[..., -1].set(1.0)
        use_e1 = jnp.abs(xu[..., 0:1]) > 0.9
        e_base = jnp.where(use_e1, e1, e0)
        
        proj_e = e_base - safe_dot(e_base, xu, keepdims=True) * xu
        u_fallback = proj_e / jnp.maximum(safe_norm(proj_e, keepdims=True), eps)
        log_antipodal = jnp.pi * u_fallback
        
        log_normal = jnp.where(degenerate, 0.0, log_normal)
        log_normal = jnp.where(degenerate, jax.lax.stop_gradient(log_normal), log_normal)
        return jnp.where(is_antipodal, jax.lax.stop_gradient(log_antipodal), log_normal)

    @staticmethod
    @jit
    def log_map_newton(x: jnp.ndarray, y: jnp.ndarray) -> jnp.ndarray:
        eps = jnp.finfo(x.dtype).eps
        xu = x / jnp.maximum(safe_norm(x, keepdims=True), eps)
        yu = y / jnp.maximum(safe_norm(y, keepdims=True), eps)
        
        v0 = GeodesicKernels._log_map_unit(xu, yu)
        
        dot = jnp.clip(safe_dot(xu, yu, keepdims=True), -1.0, 1.0)
        is_antipodal = dot <= (-1.0 + 10.0 * eps * jnp.sqrt(jnp.maximum(x.shape[-1], 1)))
        
        e0 = jnp.zeros_like(xu).at[..., 0].set(1.0)
        e1 = jnp.zeros_like(xu).at[..., -1].set(1.0)
        use_e1 = jnp.abs(xu[..., 0:1]) > 0.9
        e_base = jnp.where(use_e1, e1, e0)
        proj_e = e_base - safe_dot(e_base, xu, keepdims=True) * xu
        u_fallback = proj_e / jnp.maximum(safe_norm(proj_e, keepdims=True), eps)
        log_antipodal = jnp.pi * u_fallback
        
        v0 = jnp.where(is_antipodal, log_antipodal, v0)
        
        def body_fn(_, v):
            y_approx = GeodesicKernels.exp_map(xu, v)
            y_approx = y_approx / jnp.maximum(safe_norm(y_approx, keepdims=True), eps)
            residual = GeodesicKernels._log_map_unit(y_approx, yu)
            
            c = safe_dot(y_approx, xu, keepdims=True)
            denom = jnp.maximum(1.0 + c, 1e-12)
            trans_res = residual - (safe_dot(residual, y_approx + xu, keepdims=True) / denom) * (y_approx + xu)
            return v + trans_res
            
        return jax.lax.fori_loop(0, 2, lambda i, v: body_fn(i, v), v0)

    @staticmethod
    @jit
    def slerp(q1: jnp.ndarray, q2: jnp.ndarray, t: jnp.ndarray) -> jnp.ndarray:
        eps = jnp.finfo(q1.dtype).eps
        q1_u = q1 / jnp.maximum(safe_norm(q1, keepdims=True), eps)
        q2_u = q2 / jnp.maximum(safe_norm(q2, keepdims=True), eps)
        
        dot_raw = safe_dot(q1_u, q2_u, keepdims=True)
        dot = jnp.clip(dot_raw, -1.0, 1.0)
        
        margin = 10.0 * eps
        dot_grad_safe = jnp.clip(dot_raw, -1.0 + margin, 1.0 - margin)
        theta = jnp.arccos(dot_grad_safe)
        
        is_ident = dot >= (1.0 - 1e-5)
        is_anti = dot <= (-1.0 + 1e-5)
        
        sin_t = jnp.where(is_ident | is_anti, 1.0, jnp.sin(theta))
        c1 = jnp.sin((1.0 - t) * theta) / sin_t
        c2 = jnp.sin(t * theta) / sin_t
        
        interp = c1 * q1_u + c2 * q2_u
        interp = interp / jnp.maximum(safe_norm(interp, keepdims=True), eps)
        
        dim = q1.shape[-1]
        e0 = jnp.zeros_like(q1_u).at[..., 0].set(1.0)
        e1 = jnp.zeros_like(q1_u).at[..., -1].set(1.0)
        e_base = jnp.where(jnp.abs(q1_u[..., 0:1]) > 0.9, e1, e0)
        proj_e = e_base - safe_dot(e_base, q1_u, keepdims=True) * q1_u
        u = proj_e / jnp.maximum(safe_norm(proj_e, keepdims=True), eps)
        
        lerp_anti = jnp.cos(jnp.pi * t) * q1_u + jnp.sin(jnp.pi * t) * u
        lerp_anti = lerp_anti / jnp.maximum(safe_norm(lerp_anti, keepdims=True), eps)
        
        ans = jnp.where(is_ident, q1_u, interp)
        ans = jnp.where(is_anti, lerp_anti, ans)
        return ans

class CliffordRotors:
    @staticmethod
    @jit
    def apply_spherical_rotor(x: jnp.ndarray, U: jnp.ndarray, V: jnp.ndarray) -> jnp.ndarray:
        eps = jnp.finfo(x.dtype).eps
        U = U[..., None] if U.ndim == 1 else U
        V = V[..., None] if V.ndim == 1 else V
        
        W = jnp.concatenate([U, V], axis=-1)
        W_reg = W + 1e-12 * jax.random.normal(jax.random.PRNGKey(42), W.shape, dtype=W.dtype)
        
        Q, _ = jnp.linalg.qr(W_reg)
        U_orth = Q[..., :U.shape[-1]]
        V_orth = Q[..., U.shape[-1]:]
        
        # Corregir la notación del einsum para contraer sobre la dimensión D (Fix Clifford FFI)
        dot_U = jnp.einsum('...dr,...d->...r', U_orth, x)
        dot_V = jnp.einsum('...dr,...d->...r', V_orth, x)
        
        theta = 0.1
        c, s = jnp.cos(theta), jnp.sin(theta)
        rot_U = c * dot_U - s * dot_V
        rot_V = s * dot_U + c * dot_V
        
        # Reconstruir delta expandiendo a [..., None, :] y sumando en la dimensión de rotor (axis=-1)
        delta_U = (rot_U - dot_U)[..., None, :] * U_orth
        delta_V = (rot_V - dot_V)[..., None, :] * V_orth
        delta = jnp.sum(delta_U, axis=-1) + jnp.sum(delta_V, axis=-1)
        
        result = x + delta
        return result / jnp.maximum(safe_norm(result, keepdims=True), eps)

    @staticmethod
    @jit
    def cayley_transform(A: jnp.ndarray) -> jnp.ndarray:
        A_skew = 0.5 * (A - A.swapaxes(-1, -2))
        I = jnp.eye(A_skew.shape[-1], dtype=A_skew.dtype)
        reg = 1e-12 * I
        return jax.scipy.linalg.solve(I - A_skew + reg, I + A_skew)

# =====================================================================
# 4. PMTP PROTOCOLO DE MEMORIA COMPARTIDA LOCAL Y MAC CONSTANT-TIME
# =====================================================================

MAX_TENSOR_PAYLOAD_BYTES = 512 * 1024 * 1024
PMTP_VERSION = 74
PMTP_MAGIC = 0x504F4C5944494D38

_net_executor = ThreadPoolExecutor(max_workers=16)
_disk_executor = ThreadPoolExecutor(max_workers=2)

atexit.register(lambda: _net_executor.shutdown(wait=False))
atexit.register(lambda: _disk_executor.shutdown(wait=True))

DTYPE_TABLE = {
    jnp.dtype("float32"): 1,
    jnp.dtype("float64"): 2,
    jnp.dtype("float16"): 3,
    jnp.bfloat16: 4,
    jnp.dtype("int32"): 5,
    jnp.dtype("int64"): 6,
    jnp.dtype("uint8"): 7,
    jnp.dtype("uint16"): 8,
    jnp.dtype("uint32"): 9,
}
DTYPE_REVERSE = {v: k for k, v in DTYPE_TABLE.items()}

PMTP_HEADER_FMT = "<QQQQQQ32s" + "Q" * 8
PMTP_HEADER_SIZE = struct.calcsize(PMTP_HEADER_FMT)
_MAC_OFFSET = struct.calcsize("<QQQQQQ")

PMTP_NET_KEY = os.environ.get("POLYDIM_PMTP_KEY", "").encode() or None

def pmtp_mac(payload: bytes) -> bytes:
    if PMTP_NET_KEY:
        return hmac.new(PMTP_NET_KEY, payload, hashlib.sha256).digest()[:32]
    return hashlib.blake2b(payload, digest_size=32).digest()

def _dtype_to_code(dt):
    if hasattr(dt, 'name'):
        norm_dt = jnp.dtype(dt.name)
    else:
        norm_dt = jnp.dtype(dt)
        
    code = DTYPE_TABLE.get(norm_dt)
    if code is None:
        if norm_dt == jnp.bfloat16 or str(norm_dt) == 'bfloat16':
            return 4
        raise ValueError(f"PMTP no soporta dtype {dt}. Soportados: {list(DTYPE_TABLE.keys())}")
    return code

def _np_dtype_for_code(code: int):
    dt = DTYPE_REVERSE[code]
    return ml_dtypes.bfloat16 if dt == jnp.bfloat16 else dt

class PMTPPersistentStorage:
    @classmethod
    def save_tensor(cls, path: str, tensor: jnp.ndarray, metadata_gen: int = 1):
        return _disk_executor.submit(cls._blocking_save, path, tensor, metadata_gen)

    @classmethod
    def _blocking_save(cls, path: str, tensor: jnp.ndarray, metadata_gen: int):
        host_arr = np.ascontiguousarray(jax.device_get(tensor))
        
        if sys.byteorder == 'big':
            host_arr = host_arr.byteswap()
            
        payload_bytes = host_arr.tobytes()
        
        shape = list(tensor.shape)
        ndim = len(shape)
        if ndim > 8:
            raise ValueError(f"PMTP V74 soporta máximo 8 dimensiones, recibido {ndim}")
        shape_padded = (shape + [0] * 8)[:8]
        
        zero_mac = b"\x00" * 32
        header = bytearray(struct.pack(
            PMTP_HEADER_FMT,
            PMTP_MAGIC, PMTP_VERSION, ndim, _dtype_to_code(tensor.dtype),
            len(payload_bytes), int(time.time_ns()), zero_mac,
            *shape_padded
        ))
        
        mac = pmtp_mac(bytes(header) + payload_bytes)
        header[_MAC_OFFSET:_MAC_OFFSET + 32] = mac
        header_data = bytes(header)
        
        dir_name = os.path.dirname(os.path.abspath(path))
        if dir_name:
            os.makedirs(dir_name, exist_ok=True)
        temp_path = os.path.join(dir_name or ".", f".tmp_{uuid.uuid4().hex}")
        
        try:
            with open(temp_path, "wb") as f:
                f.write(header_data)
                f.write(payload_bytes)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp_path, path)
            
            # fsync de directorio para confirmación atómica en POSIX
            if dir_name and hasattr(os, "O_DIRECTORY"):
                try:
                    dir_fd = os.open(dir_name, os.O_RDONLY | os.O_DIRECTORY)
                    try:
                        os.fsync(dir_fd)
                    finally:
                        os.close(dir_fd)
                except Exception:
                    pass
        except Exception as e:
            if os.path.exists(temp_path):
                try: os.unlink(temp_path)
                except: pass
            raise e

    @classmethod
    def load_tensor(cls, path: str, with_meta: bool = False):
        header_size = PMTP_HEADER_SIZE
        if not os.path.exists(path) or os.path.getsize(path) < header_size:
            raise ValueError("Archivo PMTP vacío o corrupto")
            
        with open(path, "rb") as f:
            header_bytes = f.read(header_size)
            if len(header_bytes) < header_size:
                raise ValueError("PMTP truncado: cabecera incompleta")
            fields = struct.unpack(PMTP_HEADER_FMT, header_bytes)
            magic, version, ndim, dtype_code, payload_bytes, ts, mac = fields[:7]
            shape = list(fields[7:7+ndim])
            
            if magic != PMTP_MAGIC or version != PMTP_VERSION:
                raise ValueError("Archivo PMTP inválido o versión mismatch")
                
            if payload_bytes > MAX_TENSOR_PAYLOAD_BYTES:
                raise ValueError("Payload de archivo excede los límites seguros")
                
            mac_calc = hmac.new(PMTP_NET_KEY, digestmod=hashlib.sha256) if PMTP_NET_KEY else hashlib.blake2b(digest_size=32)
            header_zero = bytearray(header_bytes)
            header_zero[_MAC_OFFSET:_MAC_OFFSET + 32] = b"\x00" * 32
            mac_calc.update(bytes(header_zero))
            
            payload_buf = bytearray(payload_bytes)
            view = memoryview(payload_buf)
            bytes_left = payload_bytes
            offset = 0
            while bytes_left > 0:
                chunk = f.read(min(65536, bytes_left))
                if not chunk:
                    raise ValueError("Payload de archivo truncado")
                mac_calc.update(chunk)
                view[offset:offset+len(chunk)] = chunk
                offset += len(chunk)
                bytes_left -= len(chunk)
                
            if not hmac.compare_digest(mac_calc.digest()[:32], mac):
                raise ValueError("MAC mismatch en archivo (corrupción)")
                
            dtype = _np_dtype_for_code(dtype_code)
            arr = np.frombuffer(payload_buf, dtype=dtype).reshape(shape)
            
            if sys.byteorder == 'big':
                arr = arr.byteswap()
                
            arr = arr.copy()
            out = jax.device_put(arr)
            
            if with_meta:
                meta = {"version": version, "dtype_code": dtype_code, "timestamp_ns": ts, "shape": shape}
                return out, meta
            return out

    @classmethod
    def read_metadata(cls, path: str) -> dict:
        if not os.path.exists(path) or os.path.getsize(path) < PMTP_HEADER_SIZE:
            raise ValueError("Archivo PMTP vacío o corrupto")
        with open(path, "rb") as f:
            header_bytes = f.read(PMTP_HEADER_SIZE)
            fields = struct.unpack(PMTP_HEADER_FMT, header_bytes)
        if fields[0] != PMTP_MAGIC:
            raise ValueError("PMTP inválido")
        ndim = fields[2]
        if not (1 <= ndim <= 8):
            raise ValueError("ndim inválido en metadatos")
        return {"version": fields[1], "dtype_code": fields[3], "timestamp_ns": fields[5], "shape": list(fields[7:7 + ndim])}

class PMTPAgentBridge:
    def __init__(self, host: str = "127.0.0.1", port: int = 0):
        self.host = host
        self.port = port
        self.inbox = Queue(maxsize=100)
        self._inbox_lock = threading.Lock()
        self.server_socket = None
        self.running = False
        self.dropped_count = 0

    def start_server(self):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.port = self.server_socket.getsockname()[1]
        self.server_socket.listen(128)
        self.running = True
        threading.Thread(target=self._listen_loop, daemon=True).start()

    def _listen_loop(self):
        while self.running:
            try:
                conn, _ = self.server_socket.accept()
                _net_executor.submit(self._handle_connection, conn)
            except:
                break

    def stop_server(self):
        self.running = False
        if self.server_socket:
            self.server_socket.close()

    @staticmethod
    def _recv_exact(conn: socket.socket, n: int) -> bytes:
        buf = bytearray(n)
        view = memoryview(buf)
        bytes_read = 0
        while bytes_read < n:
            try:
                chunk_size = conn.recv_into(view[bytes_read:], min(65536, n - bytes_read))
                if not chunk_size:
                    return None
                bytes_read += chunk_size
            except (socket.timeout, ConnectionResetError, BrokenPipeError, OSError):
                return None
        return bytes(buf)

    def _handle_connection(self, conn: socket.socket):
        try:
            with conn:
                conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                conn.settimeout(10.0)
                
                h_size = PMTP_HEADER_SIZE
                first = conn.recv(h_size)
                if not first:
                    return
                rest = self._recv_exact(conn, h_size - len(first))
                if rest is None:
                    return
                header_bytes = first + rest
                
                fields = struct.unpack(PMTP_HEADER_FMT, header_bytes)
                magic, version, ndim, dtype_code, payload_bytes, ts, mac = fields[:7]
                
                if magic != PMTP_MAGIC or version != PMTP_VERSION: return
                if payload_bytes > MAX_TENSOR_PAYLOAD_BYTES: return
                if not (1 <= ndim <= 8): return
                if dtype_code not in DTYPE_REVERSE: return
                
                shape = list(fields[7:7+ndim])
                dtype = _np_dtype_for_code(dtype_code)
                
                # Validar coherencia de shape y bytes antes de asignar (Vector DoS validation)
                n_items = 1
                for s_ in shape:
                    n_items *= s_
                if n_items * np.dtype(dtype).itemsize != payload_bytes:
                    return
                
                payload_buf = bytearray(payload_bytes)
                view = memoryview(payload_buf)
                bytes_left = payload_bytes
                offset = 0
                while bytes_left > 0:
                    try:
                        chunk_size = conn.recv_into(view[offset:], min(65536, bytes_left))
                        if not chunk_size:
                            return
                        offset += chunk_size
                        bytes_left -= chunk_size
                    except OSError:
                        return
                    
                mac_calc = hmac.new(PMTP_NET_KEY, digestmod=hashlib.sha256) if PMTP_NET_KEY else hashlib.blake2b(digest_size=32)
                header_zero = bytearray(header_bytes)
                header_zero[_MAC_OFFSET:_MAC_OFFSET + 32] = b"\x00" * 32
                mac_calc.update(bytes(header_zero))
                mac_calc.update(payload_buf)
                    
                if not hmac.compare_digest(mac_calc.digest()[:32], mac):
                    return
                    
                if sys.byteorder == 'big':
                    payload_buf = payload_buf.byteswap()
                
                tensor = jax.device_put(np.frombuffer(payload_buf, dtype=dtype).reshape(shape).copy())
                
                try:
                    self.inbox.put(tensor, block=False)
                except Full:
                    with self._inbox_lock:
                        self.dropped_count += 1
        except Exception as e:
            warnings.warn(f"Error en _handle_connection: {e}")

    @staticmethod
    def send_tensor(host: str, port: int, tensor: jnp.ndarray, timeout: float = 5.0) -> bool:
        try:
            host_arr = np.ascontiguousarray(jax.device_get(tensor))
            if sys.byteorder == 'big':
                host_arr = host_arr.byteswap()
                
            payload = host_arr.tobytes()
            shape = list(tensor.shape)
            ndim = len(shape)
            if ndim > 8:
                raise ValueError(f"PMTP ndim={ndim} excede 8")
            shape_padded = (shape + [0] * 8)[:8]
            
            zero_mac = b"\x00" * 32
            header = bytearray(struct.pack(
                PMTP_HEADER_FMT,
                PMTP_MAGIC, PMTP_VERSION, ndim,
                _dtype_to_code(tensor.dtype), len(payload),
                time.time_ns(), zero_mac,
                *shape_padded
            ))
            
            mac = pmtp_mac(bytes(header) + payload)
            header[_MAC_OFFSET:_MAC_OFFSET + 32] = mac
            
            with socket.create_connection((host, port), timeout=timeout) as s:
                s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                s.settimeout(timeout)
                s.sendall(bytes(header))
                s.sendall(payload)
            return True
        except (socket.timeout, ConnectionRefusedError, OSError) as e:
            warnings.warn(f"PMTP send_tensor falló a {host}:{port}: {e}")
            return False

# =====================================================================
# 5. SUITE EMPÍRICA V74 (14 Tests Verdes Conservados y Validados)
# =====================================================================

def run_self_verification():
    print("=" * 60)
    print("SUITE EMPÍRICA POLYDIM V74 — REDTEAM ORACLE CERTIFIED")
    print("=" * 60)
    
    NativeFFIBridge.initialize()
    print("Kernel nativo activo:", NativeFFIBridge._get_preferred())
    
    # --- T1: FFI Householder no-trivial ---
    x_ffi = jnp.array([1.0, 0.0, 0.0])
    v_ffi = jnp.array([1.0, 1.0, 0.0])
    out_ffi = NativeFFIBridge.householder_reflect(x_ffi, v_ffi)
    expected = jnp.array([0.0, -1.0, 0.0])
    assert jnp.allclose(out_ffi, expected, atol=1e-12), f"T1 FAIL: {out_ffi}"
    print("[T1] FFI householder no-trivial            OK")
    
    # --- T2: FFI batched vs fallback JAX ---
    xb = jax.random.normal(jax.random.PRNGKey(1), (7, 5), dtype=jnp.float64)
    vb = jax.random.normal(jax.random.PRNGKey(2), (7, 5), dtype=jnp.float64)
    got = NativeFFIBridge.householder_reflect(xb, vb)
    denom_b = jnp.sum(vb * vb, -1, keepdims=True)
    ref = xb - 2.0 * jnp.sum(xb * vb, -1, keepdims=True) / jnp.maximum(denom_b, 1e-30) * vb
    assert jnp.allclose(got, ref, atol=1e-12), "T2 batched FFI vs JAX FAIL"
    print("[T2] FFI batched == JAX ref                 OK")
    
    # --- T3: FFI scrub subnormales batched ---
    sub_val = struct.unpack('<d', struct.pack('<q', 1))[0]
    data_sub = jnp.array([[1.0, sub_val], [sub_val, 3.0]])
    clean = NativeFFIBridge.scrub_subnormals(data_sub)
    assert float(clean[0, 1]) == 0.0 and float(clean[1, 0]) == 0.0, "T3 scrub subnormales FAIL"
    print("[T3] scrub subnormales batched              OK")
    
    # --- T4: Gradiente vivo en log_map ---
    k = jax.random.PRNGKey(7)
    xg = jax.random.normal(k, (8,))
    xg = xg / jnp.linalg.norm(xg)
    yg = jax.random.normal(jax.random.split(k)[0], (8,))
    yg = yg / jnp.linalg.norm(yg)
    g = jax.grad(lambda x_: jnp.sum(GeodesicKernels.log_map(x_, yg) ** 2))(xg)
    assert float(jnp.max(jnp.abs(g))) > 1e-8, "T4 GRADIENTE MUERTO en log_map"
    print("[T4] gradiente log_map vivo                 OK")
    
    # --- T5: PMTP roundtrip en dtypes ---
    with tempfile.TemporaryDirectory() as tmp:
        for code, jdt in DTYPE_REVERSE.items():
            np_dt = _np_dtype_for_code(code)
            base = (np.arange(12, dtype=np.int32) % 7).astype(np_dt)
            t = jnp.array(base)
            p = os.path.join(tmp, f"t_{code}.pmtp")
            PMTPPersistentStorage.save_tensor(p, t).result()
            back = PMTPPersistentStorage.load_tensor(p)
            if np.issubdtype(np_dt, np.floating):
                tol = 1e-3 if np_dt == ml_dtypes.bfloat16 else 1e-6
                assert np.allclose(np.asarray(back), base, atol=tol, rtol=tol), f"T5 dtype {jdt} FAIL"
            else:
                assert np.array_equal(np.asarray(back), base), f"T5 dtype {jdt} FAIL"
    print("[T5] PMTP roundtrip x9 dtypes               OK")
    
    # --- T6: Slerp extremos exactos ---
    q1 = jnp.array([1.0, 0.0, 0.0, 0.0])
    q2 = jnp.array([0.0, 1.0, 0.0, 0.0])
    assert jnp.allclose(GeodesicKernels.slerp(q1, q2, jnp.array(0.0)), q1, atol=1e-6)
    assert jnp.allclose(GeodesicKernels.slerp(q1, q2, jnp.array(1.0)), q2, atol=1e-6)
    print("[T6] slerp endpoints                        OK")
    
    # --- T6b: Gradiente slerp finito cerca de dot=1 ---
    q1_b = jnp.array([1.0, 0.0, 0.0, 0.0])
    rnd = jax.random.normal(jax.random.PRNGKey(11), (4,))
    q2_close = q1_b + 1e-6 * rnd / jnp.linalg.norm(rnd)
    q2_close = q2_close / jnp.linalg.norm(q2_close)
    g_slerp = jax.grad(lambda q: jnp.sum(GeodesicKernels.slerp(q1_b, q, jnp.array(0.37)) ** 2))(q2_close)
    assert bool(jnp.isfinite(g_slerp).all()), "T6b: NaN en gradiente de slerp"
    print("[T6b] gradiente slerp finito cerca de 1     OK")
    
    # --- T7: Idempotencia geodésica D=10^6 ---
    D = 1000000
    key = jax.random.PRNGKey(42)
    x = jax.random.normal(key, (D,), dtype=jnp.float32)
    x /= jnp.linalg.norm(x)
    y = jax.random.normal(jax.random.split(key)[0], (D,), dtype=jnp.float32)
    y /= jnp.linalg.norm(y)
    
    y_newton = GeodesicKernels.exp_map(x, GeodesicKernels.log_map_newton(x, y))
    
    cos_sim = jnp.clip(jnp.dot(y, y_newton), -1.0, 1.0)
    angular_err = jnp.arccos(jnp.abs(cos_sim))
    assert float(angular_err) < 1e-3, f"T7 FAIL: angular_err={angular_err:.2e}"
    print(f"[T7] exp o log idempotencia D=10^6 err={angular_err:.2e} OK")
    
    # --- T8: TCP roundtrip local real ---
    bridge = PMTPAgentBridge()
    bridge.start_server()
    atexit.register(bridge.stop_server)
    t_send = jnp.array([4.0, 5.0, 6.0], dtype=jnp.float32)
    PMTPAgentBridge.send_tensor("127.0.0.1", bridge.port, t_send)
    
    time.sleep(0.5)
    bridge.stop_server()
    assert not bridge.inbox.empty(), "T8: Inbox vacía"
    t_recv = bridge.inbox.get()
    assert jnp.allclose(t_send, t_recv), "T8 FAIL: Tensor recibido no coincide"
    print("[T8] TCP roundtrip local real               OK")
    
    # --- T9: Oráculo cruzado C++ vs Rust ---
    CppFFIBridge.initialize()
    if CppFFIBridge._cpp_dll is not None and NativeFFIBridge._rust_dll is not None:
        rng = np.random.default_rng(3)
        xr = rng.standard_normal((33, 6))
        vr = rng.standard_normal((33, 6))
        out_cpp = np.empty_like(xr)
        h = CppFFIBridge._cpp_dll.polydim_cpp_householder_reflect
        for i in range(33):
            h(
                xr[i].ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                vr[i].ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                out_cpp[i].ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
                ctypes.c_size_t(6)
            )
        out_rust = NativeFFIBridge._ffi_householder_rows(xr, vr)
        assert out_rust is not None and np.allclose(out_cpp, out_rust, atol=1e-12), "T9: C++ != Rust"
        
        assert h(None, None, None, ctypes.c_size_t(4)) == -1, "T9: null no da -1"
        buf_t = np.ones(4)
        p_t = buf_t.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        assert h(p_t, p_t, p_t, ctypes.c_size_t(4)) == -2, "T9: overlap no detectado"
        print("[T9] C++ == Rust + guards -1/-2             OK")
    else:
        print("[T9] C++ o Rust sin compilar (SKIP)         OK")
        
    # --- T10: log_map works for D=1 ---
    x1 = jnp.array([1.0])
    y1 = jnp.array([-1.0])
    l1 = GeodesicKernels.log_map(x1, y1)
    assert jnp.allclose(l1, jnp.array([0.0])), f"T10 FAIL: l1={l1}"
    print("[T10] log_map D=1 (S^0)                    OK")
    
    # --- T11: Newton no degenera en pares cercanos ---
    k11 = jax.random.PRNGKey(13)
    x11 = jax.random.normal(k11, (16,))
    x11 /= jnp.linalg.norm(x11)
    n11 = jax.random.normal(jax.random.split(k11)[0], (16,))
    n11 /= jnp.linalg.norm(n11)
    y11 = x11 + 1e-4 * n11
    y11 /= jnp.linalg.norm(y11)
    y11_hat = GeodesicKernels.exp_map(x11, GeodesicKernels.log_map_newton(x11, y11))
    err11 = float(jnp.max(jnp.abs(y11_hat - y11)))
    assert err11 < 1e-6, f"T11 FAIL err={err11:.2e}"
    print(f"[T11] Newton pares cercanos f32 err={err11:.2e} OK")
    
    # --- T12: Metadata legible ---
    with tempfile.TemporaryDirectory() as tmp_dir:
        p12 = os.path.join(tmp_dir, "meta.pmtp")
        PMTPPersistentStorage.save_tensor(p12, jnp.array([1.0, 2.0])).result()
        m = PMTPPersistentStorage.read_metadata(p12)
        assert m["version"] == PMTP_VERSION and m["timestamp_ns"] > 0, "T12 FAIL"
    print("[T12] metadata PMTP legible                 OK")
    
    # --- T13: log(x, -x) tiene norma pi ---
    xa = jnp.array([1.0, 0.0, 0.0])
    la = GeodesicKernels.log_map(xa, -xa)
    assert jnp.allclose(jnp.linalg.norm(la), jnp.pi, atol=1e-5), f"T13 FAIL: ||la||={jnp.linalg.norm(la)}"
    print("[T13] log antipodal ||·||=pi                OK")
    
    # --- T14: Regression test para scrub_subnormals en múltiples dtypes ---
    f32_sub = struct.unpack('<f', struct.pack('<i', 1))[0]
    t_f32 = jnp.array([f32_sub, 1.0], dtype=jnp.float32)
    t_f32_clean = NativeFFIBridge.scrub_subnormals(t_f32)
    assert float(t_f32_clean[0]) == 0.0, "T14 FAIL: f32 subnormal no purgado"
    
    f64_sub = struct.unpack('<d', struct.pack('<q', 1))[0]
    t_f64 = jnp.array([f64_sub, 1.0], dtype=jnp.float64)
    t_f64_clean = NativeFFIBridge.scrub_subnormals(t_f64)
    assert float(t_f64_clean[0]) == 0.0, "T14 FAIL: f64 subnormal no purgado"
    print("[T14] regression scrub multi-dtypes         OK")
    
    print("=" * 60)
    print("¡LOS 14 TESTS VERDES! ARQUITECTURA CERTIFICADA EN V74.")
    print("=" * 60)

class CppFFIBridge:
    _initialized = False
    _cpp_dll = None
    _temp_files = []

    @classmethod
    def cleanup(cls):
        # Evitar descargar dos veces si compartimos handle con NativeFFIBridge
        if cls._cpp_dll is not NativeFFIBridge._cpp_dll:
            if platform.system() == "Windows":
                import _ctypes
                if cls._cpp_dll and hasattr(cls._cpp_dll, '_handle') and cls._cpp_dll._handle:
                    try:
                        _ctypes.FreeLibrary(cls._cpp_dll._handle)
                    except:
                        pass
            for path in cls._temp_files:
                try:
                    if os.path.exists(path):
                        os.unlink(path)
                except:
                    pass
        cls._temp_files.clear()

    @classmethod
    def initialize(cls):
        if cls._initialized:
            return
        NativeFFIBridge.initialize()
        if NativeFFIBridge._cpp_dll is not None:
            cls._cpp_dll = NativeFFIBridge._cpp_dll
            cls._initialized = True
            return
            
        with NativeFFIBridge._init_lock:
            if cls._initialized:
                return
            atexit.register(cls.cleanup)
            
            source_hash = hashlib.sha256(CPP_SOURCE.encode("utf-8")).hexdigest()[:16]
            out_dir = os.path.join(tempfile.gettempdir(), "POLYDIM_EINSOF_V74")
            os.makedirs(out_dir, exist_ok=True)
            
            cpp_path = os.path.join(out_dir, f"polydim_cpp_{source_hash}.cpp")
            prefix = "" if platform.system() == "Windows" else "lib"
            ext = ".dll" if platform.system() == "Windows" else ".so"
            cpp_dll = os.path.join(out_dir, f"{prefix}polydim_cpp_{source_hash}{ext}")
            
            cls._temp_files.extend([cpp_path, cpp_dll])
            
            if os.path.exists(cpp_dll):
                try:
                    cls._cpp_dll = ctypes.CDLL(cpp_dll)
                    cls._cpp_dll.polydim_cpp_householder_reflect.argtypes = [
                        ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
                        ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                    ]
                    cls._cpp_dll.polydim_cpp_householder_reflect.restype = ctypes.c_int
                    cls._cpp_dll.polydim_cpp_scrub_subnormals.argtypes = [
                        ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                    ]
                    cls._cpp_dll.polydim_cpp_scrub_subnormals.restype = ctypes.c_int
                    cls._initialized = True
                    return
                except:
                    cls._cpp_dll = None
            try:
                with open(cpp_path, "w", encoding="utf-8") as f:
                    f.write(CPP_SOURCE)
                    
                cxx = shutil.which("g++") or shutil.which("clang++") or shutil.which("c++")
                args = [cxx, "-O2", "-shared", "-fPIC", "-o", cpp_dll, cpp_path] if cxx else None
                if args is None:
                    cl = shutil.which("cl")
                    if cl:
                        args = [cl, "/nologo", "/LD", "/O2", f"/Fe:{cpp_dll}", cpp_path]
                if args is None:
                    cls._initialized = True
                    return
                subprocess.run(args, check=True, capture_output=True, timeout=30)
                cls._cpp_dll = ctypes.CDLL(cpp_dll)
                cls._cpp_dll.polydim_cpp_householder_reflect.argtypes = [
                    ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
                    ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                ]
                cls._cpp_dll.polydim_cpp_householder_reflect.restype = ctypes.c_int
                cls._cpp_dll.polydim_cpp_scrub_subnormals.argtypes = [
                    ctypes.POINTER(ctypes.c_double), ctypes.c_size_t
                ]
                cls._cpp_dll.polydim_cpp_scrub_subnormals.restype = ctypes.c_int
            except Exception as e:
                warnings.warn(f"Compilación C++ falló: {e}")
            cls._initialized = True

if __name__ == '__main__':
    try:
        run_self_verification()
    except KeyboardInterrupt:
        print("\nInterrupción del usuario. Saliendo de forma segura.")
        sys.exit(0)
