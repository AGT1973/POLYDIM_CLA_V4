"""
FIX sobre 4_BENCHMARK_PMTP.py original
=========================================
BUG (violación del dogma NO-GUSANO en la práctica, no solo en teoría):
    tensor_np = jax.device_get(tensor_jax).tolist()   # <-- lista Python
    ring.push(tensor_np)   # PyO3 convierte elemento a elemento

FIX: mandar el array de NumPy tal cual (contiguo, C-order), que ahora
sí cruza la frontera FFI sin copia elemento-por-elemento gracias al
fix del lib.rs (PyReadonlyArray1<f32>).

Requiere: recompilar einsof_rust con Cargo_FIXED.toml + lib_FIXED.rs
"""
import jax
import jax.numpy as jnp
import numpy as np
import time
import sys


def run_benchmark():
    try:
        import einsof_rust
    except ImportError:
        print("[!] ERROR: 'einsof_rust' aún no está compilado.")
        sys.exit(0)

    N = 10000
    print(f"[*] Inicializando Anillo PMTP en Rust (Capacidad=16, Dimensiones={N})")
    ring = einsof_rust.PmtpRing(16, N)

    print(f"[*] Generando tensor ND en JAX (N={N})...")
    key = jax.random.PRNGKey(42)
    tensor_jax = jax.random.normal(key, (N,))

    # --- FIX: sin .tolist(). Array numpy float32 contiguo, cruza la
    # frontera FFI vía buffer, no vía conversión Python elemento-a-elemento.
    tensor_np = np.asarray(jax.device_get(tensor_jax), dtype=np.float32)
    assert tensor_np.flags['C_CONTIGUOUS'], "el buffer debe ser contiguo para zero-copy"

    print("[*] Empujando tensor a memoria Rust (zero-copy, buffer NumPy)...")
    t0 = time.time()
    success = ring.push(tensor_np)
    t1 = time.time()

    if success:
        print(f"  -> [OK] Tensor escrito en Rust en {(t1-t0)*1000:.3f} ms")
    else:
        print("  -> [FAIL] Buffer lleno o dimensión no coincide")

    print("[*] Consumiendo tensor desde Rust...")
    t2 = time.time()
    out_tensor = ring.pop()
    t3 = time.time()

    if out_tensor:
        print(f"  -> [OK] Tensor leído desde Rust en {(t3-t2)*1000:.3f} ms")
        out_jax = jnp.array(out_tensor)
        drift = jnp.linalg.norm(tensor_jax - out_jax)
        print(f"[*] Deriva topológica (Drift de Precisión): {drift:.6e}")

        if drift < 1e-5:
            print("\n[SUCCESS] Pipeline JAX <-> Rust, FFI zero-copy real (dogma NO-GUSANO cumplido).")
        else:
            print("\n[WARNING] Corrupción de datos detectada en el puente.")
    else:
        print("  -> [FAIL] Buffer vacío")


if __name__ == "__main__":
    run_benchmark()
