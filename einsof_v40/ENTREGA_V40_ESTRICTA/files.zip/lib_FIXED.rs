//! einsof_rust — Bus PMTP lock-free + integridad HMAC-BLAKE2b
//! ============================================================
//! FIXES aplicados sobre el original:
//!
//! [CRÍTICO #4] La firma original `push(&mut self, tensor: Vec<f32>)`
//! obliga a PyO3 a construir un Vec<f32> convirtiendo el iterable
//! Python elemento por elemento. Esto viola el dogma "NO-GUSANO" del
//! whitebook ("los tensores se inyectan crudos... aterrizando
//! directamente en memoria") pese a no ser JSON/Base64: sigue siendo
//! marshalling objeto-por-objeto, no un puntero a buffer contiguo.
//! FIX: usar `numpy::PyReadonlyArray1<f32>` (requiere agregar la
//! crate `numpy` a Cargo.toml) para acceso zero-copy al buffer real
//! de NumPy.
//!
//! [GRAVE #5] `copy_from_slice` panica si `tensor.len() != dim`.
//! Sin este chequeo, un mismatch de dimensión (typo, config
//! desalineada) puede abortar el proceso Python entero.
//! FIX: validar longitud y devolver `false` en vez de panicar.
//!
//! Cargo.toml requiere agregar:
//!   numpy = "0.21"   # (ajustar a la versión compatible con pyo3 0.29)

use std::sync::atomic::{AtomicU64, Ordering};

const CACHE_LINE: usize = 64;

#[repr(align(64))]
struct CacheAligned(AtomicU64);

pub struct PmtpRing {
    head: CacheAligned,
    tail: CacheAligned,
    capacity: usize,
    dim: usize,                  // FIX: guardamos dim explícitamente
    slots: Vec<Vec<f32>>,
    sequences: Vec<AtomicU64>,
}

impl PmtpRing {
    pub fn new(capacity: usize, dim: usize) -> Self {
        assert!(capacity.is_power_of_two(), "capacity debe ser potencia de 2");
        let slots = (0..capacity).map(|_| vec![0.0f32; dim]).collect();
        let sequences = (0..capacity).map(|i| AtomicU64::new(i as u64)).collect();
        PmtpRing {
            head: CacheAligned(AtomicU64::new(0)),
            tail: CacheAligned(AtomicU64::new(0)),
            capacity,
            dim,
            slots,
            sequences,
        }
    }

    /// Produce un tensor. Retorna false si el buffer está lleno
    /// O si la dimensión no coincide (FIX grave #5: antes panicaba).
    pub fn push(&mut self, tensor: &[f32]) -> bool {
        // --- FIX GRAVE #5: guard de longitud, antes ausente ---
        if tensor.len() != self.dim {
            return false;
        }

        let head = self.head.0.load(Ordering::Relaxed);
        let slot = (head as usize) & (self.capacity - 1);
        let seq = self.sequences[slot].load(Ordering::Acquire);
        if seq != head {
            return false; // buffer lleno
        }
        self.slots[slot].copy_from_slice(tensor); // ahora seguro
        self.sequences[slot].store(head + 1, Ordering::Release);
        self.head.0.store(head + 1, Ordering::Release);
        true
    }

    pub fn pop(&mut self) -> Option<Vec<f32>> {
        let tail = self.tail.0.load(Ordering::Relaxed);
        let slot = (tail as usize) & (self.capacity - 1);
        let seq = self.sequences[slot].load(Ordering::Acquire);
        if seq != tail + 1 {
            return None;
        }
        let data = self.slots[slot].clone();
        self.sequences[slot].store(tail + self.capacity as u64, Ordering::Release);
        self.tail.0.store(tail + 1, Ordering::Release);
        Some(data)
    }
}

pub fn machine_epsilon_f32() -> f32 {
    let mut e = 1.0f32;
    while 1.0f32 + e > 1.0f32 { e *= 0.5; }
    e * 2.0
}

pub fn machine_epsilon_f64() -> f64 {
    let mut e = 1.0f64;
    while 1.0f64 + e > 1.0f64 { e *= 0.5; }
    e * 2.0
}

pub fn slerp_omega_f64(p: &[f64], q: &[f64]) -> f64 {
    debug_assert_eq!(p.len(), q.len());
    let mut s2 = 0.0f64;
    let mut c2 = 0.0f64;
    for (&a, &b) in p.iter().zip(q.iter()) {
        let d = a - b;
        let s = a + b;
        s2 = d.mul_add(d, s2);
        c2 = s.mul_add(s, c2);
    }
    2.0 * f64::atan2(s2.sqrt(), c2.sqrt())
}

// ==========================================
// EXPORTACION A PYTHON (PyO3) — FIX CRÍTICO #4
// ==========================================
use pyo3::prelude::*;
use numpy::PyReadonlyArray1;   // <-- FIX: requiere crate `numpy` en Cargo.toml

#[pyclass(name = "PmtpRing")]
pub struct PyPmtpRing {
    inner: PmtpRing,
}

#[pymethods]
impl PyPmtpRing {
    #[new]
    fn new(capacity: usize, dim: usize) -> Self {
        PyPmtpRing { inner: PmtpRing::new(capacity, dim) }
    }

    /// FIX CRÍTICO #4: recibe un numpy.ndarray por referencia (zero-copy),
    /// no una lista Python. Antes: fn push(&mut self, tensor: Vec<f32>)
    /// obligaba a .tolist() del lado Python y conversión elemento a
    /// elemento en la frontera FFI — justo lo que el dogma "NO-GUSANO"
    /// prohíbe en espíritu, aunque no sea JSON.
    ///
    /// Uso desde Python ahora:
    ///     tensor_np = jax.device_get(tensor_jax)   # numpy array, SIN .tolist()
    ///     ring.push(tensor_np)
    fn push(&mut self, tensor: PyReadonlyArray1<'_, f32>) -> PyResult<bool> {
        let slice = tensor.as_slice().map_err(|e| {
            pyo3::exceptions::PyValueError::new_err(format!(
                "tensor debe ser contiguo en memoria: {e}"
            ))
        })?;
        Ok(self.inner.push(slice))
    }

    fn pop(&mut self) -> Option<Vec<f32>> {
        self.inner.pop()
    }
}

#[pyfunction]
fn get_machine_epsilon_f32() -> f32 { machine_epsilon_f32() }

#[pyfunction]
fn get_machine_epsilon_f64() -> f64 { machine_epsilon_f64() }

#[pyfunction]
fn compute_slerp_omega(p: Vec<f64>, q: Vec<f64>) -> f64 { slerp_omega_f64(&p, &q) }

#[pymodule]
fn einsof_rust(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyPmtpRing>()?;
    m.add_function(wrap_pyfunction!(get_machine_epsilon_f32, m)?)?;
    m.add_function(wrap_pyfunction!(get_machine_epsilon_f64, m)?)?;
    m.add_function(wrap_pyfunction!(compute_slerp_omega, m)?)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_push_wrong_dim_returns_false_not_panic() {
        // FIX GRAVE #5: antes esto panicaba con copy_from_slice.
        let mut ring = PmtpRing::new(4, 8);
        let wrong_size_tensor = vec![1.0f32; 5]; // dim=8 esperado, mandamos 5
        assert_eq!(ring.push(&wrong_size_tensor), false);
    }

    #[test]
    fn test_ring_push_pop_correct_dim() {
        let mut ring = PmtpRing::new(4, 8);
        let tensor = vec![1.0f32; 8];
        assert!(ring.push(&tensor));
        let out = ring.pop().expect("debe haber un elemento");
        assert_eq!(out, tensor);
    }

    #[test]
    fn test_cache_line_separation() {
        let ring = PmtpRing::new(4, 100);
        let head_addr = &ring.head.0 as *const _ as usize;
        let tail_addr = &ring.tail.0 as *const _ as usize;
        let sep = if tail_addr > head_addr { tail_addr - head_addr } else { head_addr - tail_addr };
        assert!(sep >= CACHE_LINE, "false sharing: separacion={} < CACHE_LINE={}", sep, CACHE_LINE);
    }
}
