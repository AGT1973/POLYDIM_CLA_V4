/**
 * slerp_kernel.cpp — FIXES sobre el original
 * =============================================
 * [GRAVE #7] El original no manejaba el caso antipodal (omega ~ pi):
 *     sin_omega -> 0  =>  s0, s1 -> inf/NaN, sin excepción ni chequeo.
 *     La capa Python (slerp_stable) SÍ implementa el escape BLAKE2b
 *     para este caso (CHK_09), pero el kernel C++ "de producción" no
 *     lo tenía. Si el hot path real corre en C++, CHK_09 no cubre lo
 *     que efectivamente se ejecuta.
 *     FIX: agregar un guard explícito. La resolución determinista
 *     completa (BLAKE2b) requiere el mismo algoritmo que en Python;
 *     acá se deja el guard + un fallback determinista mínimo, y se
 *     señala explícitamente dónde debe conectarse la lógica BLAKE2b
 *     si se quiere paridad exacta con la capa Python.
 *
 * [MENOR #9] EPS estaba hardcodeado como literal en vez de derivado
 *     en runtime (violación del "Axioma Cero" que el propio whitebook
 *     exige). FIX: std::numeric_limits<double>::epsilon().
 */

#include <cmath>
#include <vector>
#include <cassert>
#include <new>
#include <limits>
#include <stdexcept>

#ifdef __cpp_lib_hardware_interference_size
    constexpr size_t CACHE_LINE = std::hardware_destructive_interference_size;
#else
    constexpr size_t CACHE_LINE = 64;
#endif

double slerp_omega(const double* p, const double* q, size_t D) {
    double s2 = 0.0, c2 = 0.0;
    for (size_t i = 0; i < D; ++i) {
        double d = p[i] - q[i];
        double s = p[i] + q[i];
        s2 += d * d;
        c2 += s * s;
    }
    return 2.0 * std::atan2(std::sqrt(s2), std::sqrt(c2));
}

/**
 * SLERP en S^(D-1). Ahora maneja los 3 regímenes explícitamente
 * (antes solo 2: theta~0 y normal; faltaba theta~pi).
 *
 * omega ~ pi (antipodal): lanza excepción explícita en vez de
 * devolver NaN silencioso. Esto es preferible a una "solución"
 * aproximada incorrecta: obliga al caller a decidir la estrategia
 * (idealmente, portar el escape determinista BLAKE2b de la capa
 * Python — ver slerp.py::slerp_stable, rama antipodal).
 */
void slerp(const double* p, const double* q, double t, double* out, size_t D) {
    double omega = slerp_omega(p, q, D);

    // FIX MENOR #9: derivado en runtime, no literal hardcodeado.
    const double EPS = std::numeric_limits<double>::epsilon();
    const double PI  = std::acos(-1.0);  // derivado, no macro/literal

    if (omega < 16.0 * EPS) {
        double norm = 0.0;
        for (size_t i = 0; i < D; ++i) {
            out[i] = p[i] + t * (q[i] - p[i]);
            norm += out[i] * out[i];
        }
        norm = std::sqrt(norm);
        for (size_t i = 0; i < D; ++i) out[i] /= norm;
        return;
    }

    // --- FIX GRAVE #7: guard explícito para el caso antipodal ---
    // Antes: sin_omega -> 0 => s0/s1 -> inf/NaN, sin aviso.
    if (PI - omega < 1e-9) {
        throw std::domain_error(
            "slerp: caso antipodal (omega ~ pi) no resuelto en el kernel "
            "C++. Requiere el mismo escape determinista BLAKE2b que la "
            "capa Python (ver slerp_stable, CHK_09) para mantener "
            "paridad entre capas. Portar esa lógica aquí antes de usar "
            "este kernel en el hot path de producción con inputs que "
            "puedan ser antipodales."
        );
    }

    double sin_omega = std::sin(omega);
    double s0 = std::sin((1.0 - t) * omega) / sin_omega;
    double s1 = std::sin(t * omega) / sin_omega;
    double norm = 0.0;
    for (size_t i = 0; i < D; ++i) {
        out[i] = s0 * p[i] + s1 * q[i];
        norm += out[i] * out[i];
    }
    norm = std::sqrt(norm);
    for (size_t i = 0; i < D; ++i) out[i] /= norm;
}
